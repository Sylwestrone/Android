package com.example.ozinii.restapi;

/**
 * Created by ozinii on 10.12.17.
 */

public class Greeting {
    private String id;
    private String content;

    public String getId() {
        return id;
    }

    public String getContent() {
        return content;
    }
}
